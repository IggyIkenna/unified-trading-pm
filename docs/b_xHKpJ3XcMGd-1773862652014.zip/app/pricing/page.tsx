"use client"

import * as React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Database,
  LineChart,
  Layers,
  Zap,
  Briefcase,
  Shield,
  CheckCircle2,
  Sparkles,
  ArrowRight,
} from "lucide-react"

// Route helpers
function getStartedHref(tabKey: string, tierName: string, isCustom: boolean) {
  if (isCustom) return `/contact?service=${tabKey}&tier=${encodeURIComponent(tierName)}`
  return `/signup?service=${tabKey}&tier=${encodeURIComponent(tierName)}`
}

const pricingData = {
  data: {
    name: "Data Provision",
    icon: Database,
    color: "text-sky-400",
    tiers: [
      {
        name: "Starter",
        price: "$499",
        period: "/mo",
        description: "For individual traders and researchers",
        features: [
          "1 asset class",
          "5 venues",
          "REST API access",
          "1-day data delay",
          "100k API calls/mo",
          "Email support",
        ],
      },
      {
        name: "Professional",
        price: "$1,499",
        period: "/mo",
        description: "For trading desks and quant teams",
        features: [
          "All asset classes",
          "All 128 venues",
          "WebSocket streaming",
          "Real-time data",
          "1M API calls/mo",
          "Priority support",
          "ML Signal Feed",
        ],
        popular: true,
      },
      {
        name: "Enterprise",
        price: "Custom",
        period: "",
        description: "For institutions with custom needs",
        features: [
          "Everything in Professional",
          "Full historical data access",
          "Dedicated infrastructure",
          "Custom data feeds",
          "SLA guarantees",
          "Unlimited API calls",
          "Dedicated account manager",
          "On-premise deployment",
        ],
      },
    ],
  },
  backtesting: {
    name: "Backtesting",
    icon: LineChart,
    color: "text-violet-400",
    tiers: [
      {
        name: "Starter",
        price: "$199",
        period: "/mo",
        description: "For strategy prototyping",
        features: [
          "100 backtest hours/mo",
          "1 concurrent job",
          "Standard compute",
          "7-day result retention",
          "Community support",
        ],
      },
      {
        name: "Professional",
        price: "$799",
        period: "/mo",
        description: "For serious strategy development",
        features: [
          "500 backtest hours/mo",
          "5 concurrent jobs",
          "GPU compute available",
          "30-day result retention",
          "NL Agent interface",
          "Priority support",
        ],
        popular: true,
      },
      {
        name: "Enterprise",
        price: "Custom",
        period: "",
        description: "For quantitative firms",
        features: [
          "Unlimited backtest hours",
          "Unlimited concurrent jobs",
          "Dedicated GPU cluster",
          "Unlimited retention",
          "Full trade records export",
          "Custom integrations",
        ],
      },
    ],
  },
  execution: {
    name: "Execution",
    icon: Zap,
    color: "text-emerald-400",
    tiers: [
      {
        name: "Standard",
        price: "30%",
        period: " of alpha",
        description: "Pure alpha-based pricing",
        features: [
          "All execution algos",
          "All 128 venues",
          "Best execution reports",
          "No minimum commitment",
          "Pay only on positive alpha",
        ],
      },
      {
        name: "High Volume",
        price: "20%",
        period: " of alpha",
        description: "For higher volume traders",
        features: [
          "Everything in Standard",
          "$10M+ monthly volume",
          "Reduced alpha share",
          "Priority execution",
          "Custom algo parameters",
        ],
        popular: true,
      },
      {
        name: "Enterprise",
        price: "Custom",
        period: "",
        description: "White-label execution",
        features: [
          "Fixed fee structures",
          "Custom algo development",
          "Dedicated connectivity",
          "Co-location options",
          "Full audit trail",
        ],
      },
    ],
  },
  investment: {
    name: "Investment Mgmt",
    icon: Briefcase,
    color: "text-rose-400",
    tiers: [
      {
        name: "SMA",
        price: "0% + 35%",
        period: "",
        description: "Separately Managed Account",
        features: [
          "$100k minimum",
          "Strategy selection",
          "Custom parameters",
          "Monthly reporting",
          "30-day redemption",
          "Performance fee 20-40%",
        ],
      },
      {
        name: "Professional",
        price: "0% + 35%",
        period: "",
        description: "Via affiliate fund structure",
        features: [
          "$50k minimum",
          "House strategy allocation",
          "Same terms as principals",
          "Quarterly reporting",
          "30-day redemption",
          "High-water mark",
        ],
        popular: true,
      },
      {
        name: "Professional Plus",
        price: "Custom",
        period: "",
        description: "Custom mandates",
        features: [
          "$5M+ allocation",
          "Custom strategy design",
          "Dedicated PM",
          "Weekly reporting",
          "Negotiated terms",
          "Side letters",
        ],
      },
    ],
  },
  regulatory: {
    name: "Regulatory",
    icon: Shield,
    color: "text-slate-400",
    tiers: [
      {
        name: "Advisory",
        price: "Custom",
        period: "",
        description: "Strategic advisor engagement",
        features: [
          "Contracted advisory role",
          "Activities under supervision",
          "Streamlined onboarding",
          "Access to services",
          "Revenue sharing models",
        ],
      },
      {
        name: "AR Setup",
        price: "GBP 10k",
        period: " + 4k/mo",
        description: "Appointed Representative",
        features: [
          "Full FCA AR registration",
          "Due diligence review",
          "FCA notification",
          "Compliance manual",
          "Staff training",
          "Ongoing supervision",
        ],
        popular: true,
      },
      {
        name: "Full License",
        price: "Custom",
        period: "",
        description: "Direct authorisation support",
        features: [
          "FCA application support",
          "Regulatory capital planning",
          "Compliance framework",
          "Systems & controls",
          "Ongoing advisory",
        ],
      },
    ],
  },
  platform: {
    name: "Platform",
    icon: Layers,
    color: "text-amber-400",
    tiers: [
      {
        name: "Strategy License",
        price: "From $100k",
        period: "/strategy",
        description: "Individual strategy access",
        features: [
          "20+ strategies available",
          "Source code access",
          "Deployment support",
          "6-month bug fixes & patches",
          "Backtesting included",
          "Slack support",
        ],
      },
      {
        name: "Platform License",
        price: "Custom",
        period: "",
        description: "Full platform white-label",
        features: [
          "All 20+ strategies",
          "Full source code",
          "White-label rights",
          "Perpetual license",
          "12-month support",
          "Training included",
        ],
        popular: true,
      },
      {
        name: "Managed Service",
        price: "Custom",
        period: "",
        description: "We run it for you",
        features: [
          "Fully managed deployment",
          "24/7 monitoring",
          "Updates & maintenance",
          "Custom development",
          "Dedicated team",
        ],
      },
    ],
  },
}

export default function PricingPage() {
  const [activeTab, setActiveTab] = React.useState("data")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-3">
              <div className="flex size-9 items-center justify-center rounded-lg bg-primary">
                <Sparkles className="size-5 text-primary-foreground" />
              </div>
              <span className="text-lg font-semibold">Odum Research</span>
            </Link>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm text-muted-foreground hover:text-foreground">Services</Link>
            <Link href="/pricing" className="text-sm font-medium text-foreground">Pricing</Link>
            <Link href="/docs" className="text-sm text-muted-foreground hover:text-foreground">Documentation</Link>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/login">Sign In</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/signup">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="border-b border-border">
        <div className="container px-4 py-16 md:px-6 text-center">
          <h1 className="text-3xl font-bold md:text-4xl">Simple, Transparent Pricing</h1>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose the services you need. Scale up as you grow. No hidden fees.
          </p>
        </div>
      </section>

      {/* Pricing Tabs */}
      <section className="container px-4 py-12 md:px-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-6 mb-8">
            {Object.entries(pricingData).map(([key, data]) => {
              const Icon = data.icon
              return (
                <TabsTrigger key={key} value={key} className="flex items-center gap-2">
                  <Icon className={`size-4 ${data.color}`} />
                  <span className="hidden md:inline">{data.name}</span>
                </TabsTrigger>
              )
            })}
          </TabsList>

          {Object.entries(pricingData).map(([key, data]) => (
            <TabsContent key={key} value={key}>
              <div className="grid gap-6 md:grid-cols-3">
                {data.tiers.map((tier) => (
                  <Card 
                    key={tier.name}
                    className={tier.popular ? "border-primary shadow-lg relative" : ""}
                  >
                    {tier.popular && (
                      <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">
                        Most Popular
                      </Badge>
                    )}
                    <CardHeader>
                      <CardTitle>{tier.name}</CardTitle>
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-bold">{tier.price}</span>
                        <span className="text-muted-foreground">{tier.period}</span>
                      </div>
                      <CardDescription>{tier.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 mb-6">
                        {tier.features.map((feature) => (
                          <li key={feature} className="flex items-center gap-2 text-sm">
                            <CheckCircle2 className={`size-4 ${data.color}`} />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <Button className="w-full" variant={tier.popular ? "default" : "outline"} asChild>
                        <Link href={getStartedHref(key, tier.name, tier.price === "Custom")}>
                          {tier.price === "Custom" ? "Contact Sales" : "Get Started"}
                          <ArrowRight className="ml-2 size-4" />
                        </Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </section>

      {/* About Us / Why Odum Section */}
      <section className="border-t border-border bg-muted/30">
        <div className="container px-4 py-16 md:px-6">
          <div className="text-center mb-10">
            <Badge variant="outline" className="mb-4">About Us</Badge>
            <h2 className="text-2xl font-bold mb-2">Why Odum Research</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We built the infrastructure we needed — and now we're making it available to you.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <Card className="border-primary/20 bg-background">
              <CardHeader className="pb-2">
                <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <Database className="size-5 text-primary" />
                </div>
                <CardTitle className="text-base">We Use What We Sell</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Every strategy, every data feed, every execution algorithm runs on our own capital first. 
                  If we wouldn't trade with it, we won't sell it.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/20 bg-background">
              <CardHeader className="pb-2">
                <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <Layers className="size-5 text-primary" />
                </div>
                <CardTitle className="text-base">One Schema, Five Asset Classes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  No other platform covers TradFi, Crypto CeFi, DeFi, Sports, and Prediction Markets in a single 
                  normalised data format. We do.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/20 bg-background">
              <CardHeader className="pb-2">
                <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <Shield className="size-5 text-primary" />
                </div>
                <CardTitle className="text-base">FCA Authorised</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Fully regulated in the UK (FRN 975797). Whether you need an Appointed Representative umbrella 
                  or just peace of mind, we have the regulatory infrastructure.
                </p>
              </CardContent>
            </Card>

            <Card className="border-primary/20 bg-background">
              <CardHeader className="pb-2">
                <div className="size-10 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <Zap className="size-5 text-primary" />
                </div>
                <CardTitle className="text-base">Performance-Aligned</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Our execution fees are based on alpha generated over benchmark. If we don't beat VWAP, 
                  you don't pay premium fees. Simple.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-wrap justify-center gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-primary">128</div>
              <div className="text-sm text-muted-foreground">Live Venues</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary">6+</div>
              <div className="text-sm text-muted-foreground">Years Historical Data</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary">20+</div>
              <div className="text-sm text-muted-foreground">Battle-Tested Strategies</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary">24/7</div>
              <div className="text-sm text-muted-foreground">Trading Operations</div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="border-t border-border">
        <div className="container px-4 py-16 md:px-6">
          <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Can I combine multiple services?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Yes, our services are modular. Many clients use Data + Backtesting together, or add Execution 
                  to their existing setup. We offer bundle discounts for multi-service agreements.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">What payment methods do you accept?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  We accept bank transfers (GBP, USD, EUR), credit cards for smaller amounts, and cryptocurrency 
                  (BTC, ETH, USDC) for all services except Investment Management.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Is there a minimum commitment?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Subscription services are month-to-month with no minimum commitment. Enterprise agreements 
                  and Investment Management have minimum terms as specified in the contract.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
