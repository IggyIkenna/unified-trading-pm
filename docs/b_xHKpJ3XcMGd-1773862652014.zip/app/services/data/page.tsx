"use client"

import * as React from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Database,
  ArrowLeft,
  Search,
  Download,
  Key,
  Clock,
  CheckCircle2,
  Sparkles,
  Globe,
  Server,
  Zap,
  Filter,
  Calendar,
  FileJson,
  Copy,
  Eye,
  EyeOff,
} from "lucide-react"

// Mock data catalog
const dataFeeds = [
  { id: "btc-perps", name: "BTC Perpetuals", exchange: "Binance", type: "Order Book L2", latency: "< 10ms", status: "active", price: "$99/mo" },
  { id: "eth-perps", name: "ETH Perpetuals", exchange: "Binance", type: "Order Book L2", latency: "< 10ms", status: "active", price: "$99/mo" },
  { id: "sol-perps", name: "SOL Perpetuals", exchange: "Binance", type: "Order Book L2", latency: "< 10ms", status: "active", price: "$49/mo" },
  { id: "btc-options", name: "BTC Options", exchange: "Deribit", type: "Greeks + IV", latency: "< 50ms", status: "active", price: "$199/mo" },
  { id: "eth-options", name: "ETH Options", exchange: "Deribit", type: "Greeks + IV", latency: "< 50ms", status: "active", price: "$149/mo" },
  { id: "es-futures", name: "E-mini S&P 500", exchange: "CME", type: "Tick Data", latency: "< 5ms", status: "active", price: "$299/mo" },
  { id: "cl-futures", name: "Crude Oil", exchange: "NYMEX", type: "Tick Data", latency: "< 5ms", status: "active", price: "$199/mo" },
  { id: "uniswap-v3", name: "Uniswap V3 Pools", exchange: "Ethereum", type: "Pool State", latency: "< 1 block", status: "active", price: "$149/mo" },
  { id: "aave-v3", name: "Aave V3 Markets", exchange: "Ethereum", type: "Lending Rates", latency: "< 1 block", status: "active", price: "$99/mo" },
  { id: "nfl-odds", name: "NFL Game Odds", exchange: "Pinnacle", type: "Live Odds", latency: "< 100ms", status: "active", price: "$199/mo" },
  { id: "nba-odds", name: "NBA Game Odds", exchange: "Pinnacle", type: "Live Odds", latency: "< 100ms", status: "active", price: "$149/mo" },
  { id: "soccer-odds", name: "Soccer Odds", exchange: "Betfair", type: "Exchange Odds", latency: "< 200ms", status: "active", price: "$99/mo" },
]

const assetClasses = [
  { id: "crypto-cex", name: "Crypto CeFi", count: 15, icon: "₿" },
  { id: "crypto-defi", name: "DeFi", count: 8, icon: "Ξ" },
  { id: "tradfi-futures", name: "TradFi Futures", count: 12, icon: "📈" },
  { id: "tradfi-options", name: "Options", count: 6, icon: "🎯" },
  { id: "sports", name: "Sports", count: 10, icon: "⚽" },
]

export default function DataServicePage() {
  const [searchQuery, setSearchQuery] = React.useState("")
  const [selectedClass, setSelectedClass] = React.useState<string | null>(null)
  const [showApiKey, setShowApiKey] = React.useState(false)
  const [subscribedFeeds, setSubscribedFeeds] = React.useState<string[]>(["btc-perps", "eth-perps"])

  const filteredFeeds = dataFeeds.filter((feed) => {
    const matchesSearch = feed.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      feed.exchange.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSearch
  })

  const mockApiKey = "odum_live_sk_7f8g9h0j1k2l3m4n5o6p7q8r9s0t"

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-3">
              <div className="flex size-9 items-center justify-center rounded-lg bg-primary">
                <Sparkles className="size-5 text-primary-foreground" />
              </div>
              <span className="text-lg font-semibold">Odum Research</span>
            </Link>
            <span className="text-muted-foreground">/</span>
            <span className="text-sm font-medium">Data Provision</span>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="text-xs">
              <Globe className="mr-1 size-3" />
              128 Venues
            </Badge>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/">
                <ArrowLeft className="mr-2 size-4" />
                Back
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-8 md:px-6">
        <div className="grid gap-6 lg:grid-cols-4">
          {/* Sidebar */}
          <div className="space-y-6">
            {/* API Key Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Key className="size-4" />
                  Your API Key
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <code className="flex-1 rounded bg-muted px-2 py-1 text-xs font-mono truncate">
                    {showApiKey ? mockApiKey : "••••••••••••••••••••••••"}
                  </code>
                  <Button variant="ghost" size="sm" onClick={() => setShowApiKey(!showApiKey)}>
                    {showApiKey ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Copy className="size-4" />
                  </Button>
                </div>
                <p className="mt-2 text-xs text-muted-foreground">
                  Rate limit: 1000 req/min
                </p>
              </CardContent>
            </Card>

            {/* Asset Classes */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Asset Classes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {assetClasses.map((ac) => (
                  <button
                    key={ac.id}
                    onClick={() => setSelectedClass(selectedClass === ac.id ? null : ac.id)}
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2 rounded-md text-sm transition-colors",
                      selectedClass === ac.id
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-accent"
                    )}
                  >
                    <span className="flex items-center gap-2">
                      <span>{ac.icon}</span>
                      <span>{ac.name}</span>
                    </span>
                    <Badge variant="secondary" className="text-xs">
                      {ac.count}
                    </Badge>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Usage Stats */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">This Month</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">API Calls</span>
                  <span className="font-mono">847,291</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Data Downloaded</span>
                  <span className="font-mono">12.4 GB</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Active Feeds</span>
                  <span className="font-mono">{subscribedFeeds.length}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Monthly Cost</span>
                  <span className="font-mono font-medium text-emerald-400">$198</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Area */}
          <div className="lg:col-span-3 space-y-6">
            {/* Search + Filters */}
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search instruments, exchanges..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="mr-2 size-4" />
                Filters
              </Button>
              <Button variant="outline" size="sm">
                <Calendar className="mr-2 size-4" />
                Date Range
              </Button>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="catalog">
              <TabsList>
                <TabsTrigger value="catalog">Data Catalog</TabsTrigger>
                <TabsTrigger value="subscribed">My Subscriptions</TabsTrigger>
                <TabsTrigger value="historical">Historical Downloads</TabsTrigger>
                <TabsTrigger value="docs">API Docs</TabsTrigger>
              </TabsList>

              <TabsContent value="catalog" className="mt-4">
                <Card>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Instrument</TableHead>
                        <TableHead>Exchange</TableHead>
                        <TableHead>Data Type</TableHead>
                        <TableHead>Latency</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead className="text-right">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredFeeds.map((feed) => {
                        const isSubscribed = subscribedFeeds.includes(feed.id)
                        return (
                          <TableRow key={feed.id}>
                            <TableCell className="font-medium">{feed.name}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {feed.exchange}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-muted-foreground">{feed.type}</TableCell>
                            <TableCell>
                              <span className="flex items-center gap-1 text-emerald-400">
                                <Zap className="size-3" />
                                {feed.latency}
                              </span>
                            </TableCell>
                            <TableCell className="font-mono">{feed.price}</TableCell>
                            <TableCell className="text-right">
                              {isSubscribed ? (
                                <Button variant="ghost" size="sm" className="text-emerald-400">
                                  <CheckCircle2 className="mr-1 size-4" />
                                  Subscribed
                                </Button>
                              ) : (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setSubscribedFeeds([...subscribedFeeds, feed.id])}
                                >
                                  Subscribe
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </Card>
              </TabsContent>

              <TabsContent value="subscribed" className="mt-4">
                <Card className="p-6">
                  <div className="text-center text-muted-foreground">
                    You have {subscribedFeeds.length} active subscriptions
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="historical" className="mt-4">
                <Card className="p-6">
                  <div className="flex items-center justify-center gap-4">
                    <Download className="size-8 text-muted-foreground" />
                    <div>
                      <h3 className="font-medium">Historical Data Downloads</h3>
                      <p className="text-sm text-muted-foreground">
                        Purchase one-off historical datasets for backtesting
                      </p>
                    </div>
                    <Button>Browse Historical Data</Button>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="docs" className="mt-4">
                <Card className="p-6">
                  <div className="flex items-center gap-4">
                    <FileJson className="size-8 text-sky-400" />
                    <div>
                      <h3 className="font-medium">API Documentation</h3>
                      <p className="text-sm text-muted-foreground">
                        REST and WebSocket APIs with code examples
                      </p>
                    </div>
                    <Button variant="outline">View Docs</Button>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}
