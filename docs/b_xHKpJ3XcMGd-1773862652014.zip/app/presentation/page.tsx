"use client"

import * as React from "react"
import { motion, AnimatePresence } from "framer-motion"
import { 
  ChevronLeft, 
  ChevronRight, 
  Database, 
  LineChart, 
  Zap, 
  Shield, 
  Briefcase, 
  Layers,
  Check,
  Circle,
  ArrowRight,
  TrendingUp,
  Bot,
  GitBranch,
  Users,
  Globe,
  Play,
  Pause,
  Maximize2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { ArbitrageGalaxy } from "@/components/marketing/arbitrage-galaxy"

// Venue list for scrolling display - color-coded by asset class
const VENUE_LIST = [
  // TradFi - cyan
  { name: "IBKR", color: "cyan" },
  { name: "CME", color: "cyan" },
  { name: "NYSE", color: "cyan" },
  { name: "NASDAQ", color: "cyan" },
  { name: "ICE", color: "cyan" },
  { name: "CBOE", color: "cyan" },
  { name: "NYMEX", color: "cyan" },
  // CeFi - green
  { name: "Binance", color: "green" },
  { name: "OKX", color: "green" },
  { name: "Bybit", color: "green" },
  { name: "Deribit", color: "green" },
  { name: "Coinbase", color: "green" },
  { name: "Kraken", color: "green" },
  { name: "Hyperliquid", color: "green" },
  // DeFi - violet
  { name: "Uniswap V2", color: "violet" },
  { name: "Uniswap V3", color: "violet" },
  { name: "Uniswap V4", color: "violet" },
  { name: "Aave V3", color: "violet" },
  { name: "Morpho", color: "violet" },
  { name: "Curve", color: "violet" },
  { name: "Lido", color: "violet" },
  { name: "EtherFi", color: "violet" },
  // Sports - amber
  { name: "Betfair", color: "amber" },
  { name: "Pinnacle", color: "amber" },
  { name: "DraftKings", color: "amber" },
  { name: "FanDuel", color: "amber" },
  { name: "Bet365", color: "amber" },
  { name: "BetMGM", color: "amber" },
  { name: "Caesars", color: "amber" },
  // Predictions - rose
  { name: "Polymarket", color: "rose" },
  { name: "Kalshi", color: "rose" },
  { name: "Smarkets", color: "rose" },
]

// Slide data
const slides = [
  {
    id: 1,
    type: "cover",
    title: "Unified Trading Infrastructure",
    subtitle: "The only platform covering 5 asset classes in one unified system. Delta one and derivatives. From no-code UI to full API access.",
    tagline: "Built for professionals, by professionals",
    stats: [
      { value: "128", label: "Live Venues" },
      { value: "5", label: "Asset Classes" },
      { value: "24/7", label: "Trading" },
      { value: "6+", label: "Years Data" },
      { value: "6", label: "Revenue Lines" },
    ],
  },
  {
    id: 2,
    type: "problem",
    title: "The Multi-Asset Data Problem",
    subtitle: "Covering 5 asset classes means 4+ vendors, potentially hundreds of schemas, 4+ contracts, and endless ETL — and that's for a narrow scope of instruments per vendor. Expand to options and more instrument types, and the problem compounds.",
    costs: [
      { vendor: "Bloomberg Terminal", cost: "$25,000", period: "/user/year", asset: "TradFi" },
      { vendor: "CoinAPI / Kaiko", cost: "$500–2,000", period: "/month", asset: "Crypto" },
      { vendor: "Sportradar / Betgenius", cost: "$5,000+", period: "/month", asset: "Sports" },
      { vendor: "TheGraph / Dune", cost: "$500+", period: "/month", asset: "DeFi" },
    ],
    pain: [
      "Different formats per venue: JSON, CSV, Parquet, Zstandard, Gzip — a lot to store and transform",
      "Rate limits, retries, different protocols, terminal servers timing out",
      "Data gaps are nearly impossible to detect — missing 1 point in a million is easy to miss",
      "No single vendor covers TradFi + Crypto + DeFi + Sports + Predictions",
    ],
    solution: "One subscription. One schema. One format. 128 venues. 5 asset classes. From $499/mo.",
  },
  {
    id: 3,
    type: "moat",
    title: "Competitive Gaps We Fill",
    subtitle: "We checked. Nobody else does what we do.",
    gaps: [
      {
        competitor: "QuantConnect",
        users: "275,000 users",
        gap: "Zero DeFi support. Zero sports support. Missing OKX, Bybit, and other key exchanges.",
        color: "cyan",
      },
      {
        competitor: "NautilusTrader / Backtrader",
        users: "Popular open-source",
        gap: "Crypto-only or TradFi-only. No DeFi. No sports. No prediction markets. No unified schema.",
        color: "violet",
      },
      {
        competitor: "Sportradar / Betgenius",
        users: "Enterprise sports data",
        gap: "$5k+/month for enriched data. No backtesting. No execution. No crypto integration.",
        color: "amber",
      },
      {
        competitor: "Virtu / Instinet",
        users: "Institutional execution",
        gap: "Fixed commission regardless of performance. We only charge when we beat VWAP benchmark.",
        color: "emerald",
      },
    ],
    callout: "We're the only platform that spans all five asset classes with backtesting, execution, and investment management in a single stack.",
  },
  {
    id: 4,
    type: "coverage",
    title: "Unmatched Market Coverage",
    subtitle: "Trading 24/7/365 across all global markets",
    markets: [
      { icon: "TrendingUp", name: "TradFi", sub: "CME, ICE, NYMEX, IBKR", count: "12 venues", color: "cyan", detail: "Futures, options, equities" },
      { icon: "Database", name: "Crypto CeFi", sub: "Binance, OKX, Deribit, Bybit", count: "18 venues", color: "green", detail: "Spot, perps, options" },
      { icon: "Layers", name: "DeFi", sub: "Uniswap, Aave, Hyperliquid", count: "8 venues", color: "violet", detail: "LP, lending, on-chain perps" },
      { icon: "Globe", name: "Sports", sub: "Betfair, Pinnacle +90 more", count: "90 venues", color: "amber", detail: "Football, NFL, NBA, Tennis" },
      { icon: "LineChart", name: "Predictions", sub: "Polymarket, Kalshi", count: "4 venues", color: "rose", detail: "Political, crypto, macro" },
    ],
    instrumentCount: "1.5M+",
    instrumentNote: "instruments registered in our database (including historical/expired)",
    differentiator: "Normalised data schema across all asset classes. Enables cross-market arbitrage: BTC across CeFi/DeFi, BTC prediction markets vs CeFi derivatives (Polymarket vs Binance/Deribit), S&P data for crypto predictions, sports odds vs prediction markets. ML signals translate across domains.",
  },
  {
    id: 5,
    type: "lifecycle",
    title: "Full Lifecycle Management",
    steps: ["Design", "Simulate", "Promote", "Run", "Monitor", "Explain", "Reconcile"],
    highlight: [0, 3],
    demo: "We're going to take you through the platform we use ourselves, live — first as a Trader, seeing real-time positions and execution, then switching to the Executive view for performance, NAV, and reporting. This isn't a demo environment — it's the same system our own capital runs through.",
  },
  {
    id: 6,
    type: "revenue",
    title: "Revenue Streams",
    services: [
      { name: "Data Provision", model: "From $499/mo subscription", status: "live", note: "we use the data" },
      { name: "Backtesting as a Service", model: "From $199/mo compute credits", status: "live", note: "we use the backtest" },
      { name: "Execution as a Service", model: "30% of alpha · 20% at $10M+ volume", status: "live", note: "we use the execution" },
      { name: "Regulatory Umbrella (AR)", model: "GBP 10k setup + GBP 4k/mo", status: "active", note: "first client onboarded" },
      { name: "Investment Management", model: "0% management + 35% performance", status: "live", note: "+34.2% since Feb 2026" },
      { name: "Strategy / Platform Licence", model: "From $100k per strategy", status: "ready", note: "" },
    ],
    disclosure: "Investment Management note: +34.2% since Feb 2026 on client accounts on Binance and OKX.",
  },
  {
    id: 7,
    type: "flywheel",
    title: "Land & Expand Flywheel",
    subtitle: "Clients enter at one service, naturally expand to others. Each step increases contract value 3-10x.",
    funnel: [
      { name: "Data", sub: "entry point", active: true },
      { name: "Backtesting", sub: "test strategies", active: false },
      { name: "Execution", sub: "go live", active: false },
      { name: "Full Platform", sub: "white label", active: false },
      { name: "Investment Mgmt", sub: "we run it", active: true },
    ],
    examples: [
      "Data subscriber sees signal quality -> subscribes to BaaS",
      "BaaS client validates edge -> wants live execution",
      "Execution client scales -> needs regulatory coverage",
      "AR client grows AUM -> becomes investment management client",
    ],
  },
  {
    id: 8,
    type: "operations",
    title: "AI-Powered Efficiency",
    columns: [
      {
        title: "Autonomous Agents",
        items: [
          "P&L monitoring - real-time anomaly detection",
          "Trade quality - benchmark vs fill, flag issues",
          "Bad-trade detection - auto-escalate to human review",
          "PR review agents - detect bugs, open fix PRs",
        ],
      },
      {
        title: "Rapid Development",
        items: [
          "Strategy from concept to live in ~2 weeks",
          "New venue integration in a day",
          "Quality gates codified - lint, tests, typecheck",
          "~60 independent repos, all gated",
        ],
      },
      {
        title: "Scalable Operations",
        items: [
          "Same system serves internal + external clients",
          "Headcount scales sub-linearly with revenue",
          "Agent-assisted client onboarding",
          "Full git audit trail + GitHub issue tracking",
        ],
      },
    ],
    callout: "A competitor building this from scratch would need 15–20 people. We run the same system with a fraction of that headcount — automating the majority of workflows with human approval gates at critical decisions.",
    metrics: [
      { value: "60", label: "Repos monitored" },
      { value: "246–1,056", label: "Tests per service" },
      { value: "<1 day", label: "New venue integration" },
      { value: "~2 weeks", label: "Concept to live deployment" },
    ],
  },
  {
    id: 9,
    type: "traction",
    title: "Where We Are Today",
    achieved: [
      { text: "UTS platform operational", detail: "full lifecycle management across 5 asset classes" },
      { text: "Investment management live", detail: "clients at high watermark, +34.2% since Feb 2026" },
      { text: "First regulatory client onboarded", detail: "FCA Appointed Representative" },
      { text: "First services client delivery", detail: "in days, not months" },
    ],
    inProgress: [
      { text: "Client funding development", detail: "options on India Exchange (Delta One + Arbitrage)" },
      { text: "Building track record", detail: "for initial strategies across all asset classes" },
      { text: "Expanding AR services", detail: "in talks about further regulatory coverage" },
      { text: "MOU for execution services", detail: "institutional counterparty" },
    ],
    checkpoint: "This is a checkpoint. We're aligning on how to best diversify revenue streams, targeting the most commercially viable products and markets. The toolkit is built - now we're pointing it in the right direction.",
  },
  {
    id: 10,
    type: "ask",
    title: "Next Steps",
    subtitle: "The infrastructure is built, the regulation is in place, and the stack is live across all five asset classes. The purpose of this meeting is to sense-check the path forward — which products to lead with, which markets to prioritise, and where the advisory board can accelerate that.",
    asks: [
      {
        title: "Product Prioritisation",
        items: [
          "Which of the six revenue lines should we lead with?",
          "Where is the clearest near-term commercial opportunity?",
          "Which products are ready to scale vs. which need more runway?",
        ],
      },
      {
        title: "Strategic Partnerships",
        items: [
          "Technology partnerships for venue integration and licensing",
          "Distribution into institutional research desks and quant firms",
          "AR umbrella expansion for firms entering UK regulation",
        ],
      },
      {
        title: "Advisory Input",
        items: [
          "Help identifying which markets, products, and geographies to prioritise",
          "Guidance on what's most commercially viable — we don't have to launch everything",
          "Introductions to relevant distribution partners or anchor clients",
        ],
      },
    ],
    contact: "ikenna@odum-research.com",
  },
]

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  TrendingUp,
  Database,
  Layers,
  Globe,
  LineChart,
}

function StatusBadge({ status }: { status: string }) {
  const styles = {
    live: "bg-emerald-400/10 text-emerald-400 border-emerald-400/30",
    active: "bg-cyan-400/10 text-cyan-400 border-cyan-400/30",
    ready: "bg-amber-400/10 text-amber-400 border-amber-400/30",
  }
  return (
    <span className={cn("px-2 py-0.5 text-xs font-semibold rounded border", styles[status as keyof typeof styles])}>
      {status.toUpperCase()}
    </span>
  )
}

function MarketNode({ market }: { market: { icon: string; name: string; sub: string; color: string; count?: string; detail?: string } }) {
  const Icon = iconMap[market.icon] || Globe
  const colorStyles = {
    cyan: "border-cyan-400/40 bg-cyan-400/5",
    green: "border-emerald-400/30 bg-emerald-400/5",
    violet: "border-violet-400/30 bg-violet-400/5",
    amber: "border-amber-400/30 bg-amber-400/5",
    rose: "border-rose-400/30 bg-rose-400/5",
  }
  const textColorStyles = {
    cyan: "text-cyan-400",
    green: "text-emerald-400",
    violet: "text-violet-400",
    amber: "text-amber-400",
    rose: "text-rose-400",
  }
  return (
    <div className={cn("rounded-xl border p-4 text-center", colorStyles[market.color as keyof typeof colorStyles])}>
      <Icon className="size-6 mx-auto mb-2 text-foreground" />
      <div className="font-semibold text-sm">{market.name}</div>
      {market.count && (
        <div className={cn("text-lg font-bold mt-1", textColorStyles[market.color as keyof typeof textColorStyles])}>{market.count}</div>
      )}
      <div className="text-xs text-muted-foreground mt-1">{market.sub}</div>
      {market.detail && (
        <div className="text-[10px] text-muted-foreground/70 mt-1">{market.detail}</div>
      )}
    </div>
  )
}

export default function PresentationPage() {
  const [currentSlide, setCurrentSlide] = React.useState(0)
  const [isFullscreen, setIsFullscreen] = React.useState(false)
  const [isAutoPlay, setIsAutoPlay] = React.useState(false)
  const containerRef = React.useRef<HTMLDivElement>(null)

  const nextSlide = () => setCurrentSlide((prev) => Math.min(prev + 1, slides.length - 1))
  const prevSlide = () => setCurrentSlide((prev) => Math.max(prev - 1, 0))

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === " ") nextSlide()
      if (e.key === "ArrowLeft") prevSlide()
      if (e.key === "Escape") setIsFullscreen(false)
      if (e.key === "f") toggleFullscreen()
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  React.useEffect(() => {
    if (isAutoPlay) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length)
      }, 8000)
      return () => clearInterval(interval)
    }
  }, [isAutoPlay])

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  const slide = slides[currentSlide]

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-background flex flex-col"
    >
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-3 border-b border-border bg-card/50">
        <div className="flex items-center gap-4">
          <Link href="/" className="font-bold text-lg tracking-tight">
            ODUM<span className="text-primary">.</span>
          </Link>
          <Badge variant="outline" className="text-xs">
            <Shield className="size-3 mr-1" />
            FCA 975797
          </Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setIsAutoPlay(!isAutoPlay)}>
            {isAutoPlay ? <Pause className="size-4" /> : <Play className="size-4" />}
          </Button>
          <Button variant="ghost" size="sm" onClick={toggleFullscreen}>
            <Maximize2 className="size-4" />
          </Button>
          <span className="text-sm text-muted-foreground font-mono">
            {currentSlide + 1} / {slides.length}
          </span>
        </div>
      </header>

      {/* Slide Content */}
      <main className="flex-1 flex items-center justify-center p-8 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={slide.id}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="w-full max-w-6xl"
          >
            {/* Cover Slide */}
            {slide.type === "cover" && (
              <div className="text-center">
                <motion.h1 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="text-5xl md:text-6xl font-black tracking-tight leading-tight bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent pb-2"
                >
                  {slide.title}
                </motion.h1>
                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="mt-6 text-xl text-muted-foreground max-w-3xl mx-auto"
                >
                  {slide.subtitle}
                </motion.p>
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="mt-4 h-1 w-20 mx-auto bg-gradient-to-r from-primary to-violet-500 rounded"
                />
                <motion.p 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="mt-4 text-sm text-primary font-medium uppercase tracking-widest"
                >
                  {slide.tagline} | FCA Authorised | Ref 975797
                </motion.p>
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="mt-12 grid grid-cols-5 gap-6"
                >
                  {slide.stats?.map((stat, i) => (
                    <div key={i} className="text-center">
                      <div className="text-4xl font-bold text-primary">{stat.value}</div>
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">{stat.label}</div>
                    </div>
                  ))}
                </motion.div>
              </div>
            )}

            {/* Problem Slide */}
            {slide.type === "problem" && (
              <div>
                <h2 className="text-3xl font-bold text-primary border-b border-border pb-2 mb-2">{slide.title}</h2>
                <p className="text-muted-foreground mb-6">{slide.subtitle}</p>
                <div className="grid grid-cols-4 gap-4 mb-6">
                  {slide.costs?.map((cost, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 * i }}
                      className="p-4 rounded-lg border border-destructive/30 bg-destructive/5 text-center"
                    >
                      <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{cost.asset}</div>
                      <div className="font-semibold text-sm mb-1">{cost.vendor}</div>
                      <div className="text-xl font-bold text-destructive">{cost.cost}</div>
                      <div className="text-xs text-muted-foreground">{cost.period}</div>
                    </motion.div>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="p-4 rounded-lg border border-border bg-card">
                    <h3 className="text-sm font-semibold text-destructive uppercase tracking-wider mb-3">The Pain</h3>
                    <ul className="space-y-2">
                      {slide.pain?.map((item, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                          <span className="text-destructive">✕</span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="p-4 rounded-lg border border-primary/30 bg-primary/5">
                    <h3 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">Our Solution</h3>
                    <p className="text-lg font-semibold text-primary">{slide.solution}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Competitive Moat Slide */}
            {slide.type === "moat" && (
              <div>
                <h2 className="text-3xl font-bold text-primary border-b border-border pb-2 mb-2">{slide.title}</h2>
                <p className="text-muted-foreground mb-6">{slide.subtitle}</p>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  {slide.gaps?.map((gap, i) => {
                    const colors = {
                      cyan: "border-cyan-400/30 bg-cyan-400/5",
                      violet: "border-violet-400/30 bg-violet-400/5",
                      amber: "border-amber-400/30 bg-amber-400/5",
                      emerald: "border-emerald-400/30 bg-emerald-400/5",
                    }
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 * i }}
                        className={cn("p-4 rounded-lg border", colors[gap.color as keyof typeof colors])}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold">{gap.competitor}</span>
                          <Badge variant="outline" className="text-xs">{gap.users}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{gap.gap}</p>
                      </motion.div>
                    )
                  })}
                </div>
                <div className="p-4 rounded-lg border border-primary/30 bg-primary/5 text-center">
                  <p className="text-sm font-medium text-primary">{slide.callout}</p>
                </div>
              </div>
            )}

            {/* Coverage Slide - Animated Arbitrage Galaxy */}
            {slide.type === "coverage" && (
              <div>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-3xl font-bold text-primary border-b border-border pb-2 mb-1">{slide.title}</h2>
                    <p className="text-sm text-muted-foreground">Trading 24/7/365 — same instruments, multiple venues, continuous arbitrage</p>
                  </div>
                  <div className="flex gap-6 flex-shrink-0">
                    {[{v:"128",l:"Venues",c:"text-cyan-400"},{v:"1.5M+",l:"Instruments",c:"text-emerald-400"},{v:"5",l:"Asset Classes",c:"text-violet-400"},{v:"24/7",l:"Trading",c:"text-amber-400"}].map(s=>(
                      <div key={s.l} className="flex flex-col items-center">
                        <div className={`text-2xl font-bold tabular-nums ${s.c}`}>{s.v}</div>
                        <div className="text-[10px] text-muted-foreground text-center">{s.l}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Animated arbitrage galaxy */}
                <div className="mx-auto w-full max-w-lg">
                  <ArbitrageGalaxy />
                </div>

                {/* Scrolling venue list */}
                <div className="relative mt-4 overflow-hidden h-8">
                  <div className="absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-background to-transparent z-10" />
                  <div className="absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-background to-transparent z-10" />
                  <motion.div
                    className="flex gap-4 whitespace-nowrap"
                    animate={{ x: [0, -1200] }}
                    transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                  >
                    {[...VENUE_LIST, ...VENUE_LIST].map((venue, i) => {
                      const colors: Record<string, string> = {
                        cyan: "text-cyan-400 border-cyan-400/30",
                        green: "text-emerald-400 border-emerald-400/30",
                        violet: "text-violet-400 border-violet-400/30",
                        amber: "text-amber-400 border-amber-400/30",
                        rose: "text-rose-400 border-rose-400/30",
                      }
                      return (
                        <span
                          key={`${venue.name}-${i}`}
                          className={cn("text-xs px-2 py-1 rounded border bg-background/50", colors[venue.color])}
                        >
                          {venue.name}
                        </span>
                      )
                    })}
                  </motion.div>
                </div>

                <div className="mt-3 p-3 bg-primary/5 border-l-4 border-primary rounded-r-lg">
                  <p className="text-xs text-muted-foreground">{slide.differentiator}</p>
                </div>
              </div>
            )}

            {/* Lifecycle Slide */}
            {slide.type === "lifecycle" && (
              <div>
                <h2 className="text-3xl font-bold text-primary border-b border-border pb-2 mb-8">{slide.title}</h2>
                <div className="flex items-center gap-2 mb-8">
                  {slide.steps?.map((step, i) => (
                    <React.Fragment key={i}>
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.1 * i }}
                        className={cn(
                          "flex-1 py-4 px-3 rounded-lg border text-center font-semibold text-sm",
                          slide.highlight?.includes(i)
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border bg-card"
                        )}
                      >
                        {step}
                      </motion.div>
                      {i < (slide.steps?.length || 0) - 1 && (
                        <ArrowRight className="size-5 text-primary/50 flex-shrink-0" />
                      )}
                    </React.Fragment>
                  ))}
                </div>
                <div className="rounded-xl border border-border overflow-hidden bg-card">
                  <div className="flex items-center gap-2 px-4 py-2 bg-muted/50 border-b border-border">
                    <div className="flex gap-1.5">
                      <div className="size-3 rounded-full bg-red-400" />
                      <div className="size-3 rounded-full bg-amber-400" />
                      <div className="size-3 rounded-full bg-emerald-400" />
                    </div>
                    <div className="flex-1 bg-background rounded px-3 py-1 text-xs font-mono text-muted-foreground">
                      https://app.odum-research.co.uk/strategies
                    </div>
                  </div>
                  <div className="p-8 text-center space-y-6">
                    <p className="text-muted-foreground text-lg leading-relaxed max-w-2xl mx-auto">{slide.demo}</p>
                    <div className="flex items-center justify-center gap-4">
                      <Link href="/login?redirect=/trader" target="_blank">
                        <Button variant="outline" size="lg" className="gap-2">
                          <Play className="size-4" />
                          Trader View
                        </Button>
                      </Link>
                      <Link href="/login?redirect=/executive" target="_blank">
                        <Button size="lg" className="gap-2">
                          <Play className="size-4" />
                          Executive View
                        </Button>
                      </Link>
                    </div>
                    <p className="text-xs text-muted-foreground italic mt-4">
                      Live demo will be shown during the presentation
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Revenue Slide */}
            {slide.type === "revenue" && (
              <div>
                <h2 className="text-3xl font-bold text-primary border-b border-border pb-2 mb-6">{slide.title}</h2>
                <div className="overflow-hidden rounded-lg border border-border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-card">
                        <th className="text-left p-3 text-primary font-semibold border-b border-primary">Service</th>
                        <th className="text-left p-3 text-primary font-semibold border-b border-primary">Model</th>
                        <th className="text-left p-3 text-primary font-semibold border-b border-primary">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {slide.services?.map((service, i) => (
                        <motion.tr
                          key={i}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 * i }}
                          className="border-b border-border hover:bg-muted/50"
                        >
                          <td className="p-3 font-semibold">{service.name}</td>
                          <td className="p-3 text-muted-foreground">{service.model}</td>
                          <td className="p-3">
                            <StatusBadge status={service.status} />
                            {service.note && <span className="ml-2 text-xs text-muted-foreground">- {service.note}</span>}
                          </td>
                        </motion.tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 p-4 bg-gradient-to-r from-primary/5 to-violet-500/5 border-l-4 border-primary rounded-r-lg">
                  <p className="text-sm text-muted-foreground">{slide.disclosure}</p>
                </div>
              </div>
            )}

            {/* Flywheel Slide */}
            {slide.type === "flywheel" && (
              <div>
                <h2 className="text-3xl font-bold text-primary border-b border-border pb-2 mb-4">{slide.title}</h2>
                <p className="text-muted-foreground mb-6">{slide.subtitle}</p>
                <div className="flex items-center gap-2 mb-4">
                  {slide.funnel?.map((step, i) => (
                    <React.Fragment key={i}>
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.1 * i }}
                        className={cn(
                          "flex-1 py-4 px-3 rounded-lg border text-center",
                          step.active ? "border-primary bg-primary/10" : "border-border bg-card"
                        )}
                      >
                        <div className={cn("font-semibold text-sm", step.active && "text-primary")}>{step.name}</div>
                        <div className="text-xs text-muted-foreground">{step.sub}</div>
                      </motion.div>
                      {i < (slide.funnel?.length || 0) - 1 && (
                        <ArrowRight className="size-5 text-primary/50 flex-shrink-0" />
                      )}
                    </React.Fragment>
                  ))}
                </div>
                <div className="text-center text-xs text-muted-foreground mb-6">
                  Regulatory coverage spans all stages
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="p-6 rounded-lg border border-primary/30 bg-primary/5 text-center">
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      Data clients become backtesting clients.<br />
                      Backtesting clients want execution.<br />
                      Execution clients want the full platform.
                    </p>
                    <p className="mt-4 text-primary font-medium">Every entry point is a gateway to deeper engagement.</p>
                  </div>
                  <div className="p-4 rounded-lg border border-border bg-card">
                    <h3 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">Cross-Sell Examples</h3>
                    <ul className="space-y-2">
                      {slide.examples?.map((ex, i) => (
                        <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                          <ArrowRight className="size-4 text-primary flex-shrink-0 mt-0.5" />
                          {ex}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Operations Slide */}
            {slide.type === "operations" && (
              <div>
                <div className="flex items-start justify-between mb-4">
                  <h2 className="text-3xl font-bold text-primary border-b border-border pb-2">{slide.title}</h2>
                  <div className="flex gap-4 flex-shrink-0">
                    {slide.metrics?.map((m, i) => (
                      <div key={i} className="text-center">
                        <div className="text-xl font-bold text-primary">{m.value}</div>
                        <div className="text-[10px] text-muted-foreground">{m.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  {slide.columns?.map((col, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 * i }}
                      className="p-4 rounded-lg border border-border bg-card"
                    >
                      <h3 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">{col.title}</h3>
                      <ul className="space-y-2">
                        {col.items.map((item, j) => (
                          <li key={j} className="text-xs text-muted-foreground flex items-start gap-2">
                            <ArrowRight className="size-3 text-primary flex-shrink-0 mt-0.5" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  ))}
                </div>
                <div className="p-4 rounded-lg border border-primary/30 bg-primary/5 text-center">
                  <p className="text-sm text-muted-foreground">
                    {slide.callout?.split("15–20 people").map((part, i) => 
                      i === 0 ? part : <React.Fragment key={i}><span className="text-primary font-semibold">15–20 people</span>{part}</React.Fragment>
                    )}
                  </p>
                </div>
              </div>
            )}

            {/* Traction Slide */}
            {slide.type === "traction" && (
              <div>
                <h2 className="text-3xl font-bold text-primary border-b border-border pb-2 mb-6">{slide.title}</h2>
                <div className="grid grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-sm font-semibold text-emerald-400 uppercase tracking-wider mb-4">Achieved</h3>
                    <div className="space-y-3">
                      {slide.achieved?.map((item, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 * i }}
                          className="flex items-start gap-3 p-3 border-b border-border"
                        >
                          <Check className="size-5 text-emerald-400 flex-shrink-0" />
                          <div>
                            <div className="font-semibold text-sm">{item.text}</div>
                            <div className="text-xs text-muted-foreground">{item.detail}</div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-amber-400 uppercase tracking-wider mb-4">In Progress</h3>
                    <div className="space-y-3">
                      {slide.inProgress?.map((item, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 * i }}
                          className="flex items-start gap-3 p-3 border-b border-border"
                        >
                          <Circle className="size-5 text-amber-400 flex-shrink-0" />
                          <div>
                            <div className="font-semibold text-sm">{item.text}</div>
                            <div className="text-xs text-muted-foreground">{item.detail}</div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="mt-6 p-4 rounded-lg border border-primary/30 bg-primary/5 text-center">
                  <p className="text-sm text-muted-foreground">
                    This is a <span className="text-primary font-medium">checkpoint</span>. {slide.checkpoint?.split("checkpoint.")[1]}
                  </p>
                </div>
              </div>
            )}

            {/* Ask Slide */}
            {slide.type === "ask" && (
              <div className="text-center">
                <motion.h1 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-5xl font-black tracking-tight bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent"
                >
                  {slide.title}
                </motion.h1>
                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto"
                >
                  {slide.subtitle}
                </motion.p>
                <div className="mt-2 h-1 w-20 mx-auto bg-gradient-to-r from-primary to-violet-500 rounded" />
                <div className="grid grid-cols-3 gap-6 mt-10">
                  {slide.asks?.map((ask, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 + 0.1 * i }}
                      className="p-6 rounded-lg border border-primary/30 bg-primary/5 text-left"
                    >
                      <h3 className="text-sm font-semibold text-primary uppercase tracking-wider mb-4">{ask.title}</h3>
                      <ul className="space-y-2">
                        {ask.items.map((item, j) => (
                          <li key={j} className="text-sm text-muted-foreground flex items-start gap-2">
                            <ArrowRight className="size-4 text-primary flex-shrink-0 mt-0.5" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  ))}
                </div>
                <motion.p 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="mt-10 text-sm text-muted-foreground"
                >
                  Odum Research Ltd | FCA 975797 | {slide.contact} | odum-research.com
                </motion.p>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Navigation */}
      <footer className="flex items-center justify-between px-6 py-4 border-t border-border bg-card/50">
        <Button variant="ghost" size="sm" onClick={prevSlide} disabled={currentSlide === 0}>
          <ChevronLeft className="size-4 mr-1" />
          Previous
        </Button>
        <div className="flex gap-1">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={cn(
                "size-2 rounded-full transition-all",
                currentSlide === i ? "bg-primary w-6" : "bg-muted-foreground/30 hover:bg-muted-foreground/50"
              )}
            />
          ))}
        </div>
        <Button variant="ghost" size="sm" onClick={nextSlide} disabled={currentSlide === slides.length - 1}>
          Next
          <ChevronRight className="size-4 ml-1" />
        </Button>
      </footer>
    </div>
  )
}
