"use client"

import * as React from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Database,
  Search,
  Key,
  Copy,
  Eye,
  EyeOff,
  Plus,
  Download,
  Filter,
  ArrowLeft,
  Sparkles,
  Activity,
  Clock,
  Zap,
  Globe,
  CheckCircle2,
  AlertCircle,
  ShoppingCart,
  CreditCard,
} from "lucide-react"

// Mock data catalog
const dataCategories = [
  {
    category: "TradFi",
    feeds: [
      { name: "CME Futures", type: "OHLCV, Tick", latency: "< 50ms", status: "active", included: true },
      { name: "Options Chains", type: "IV Surface, Greeks", latency: "< 100ms", status: "active", included: true },
      { name: "Equity Spot", type: "OHLCV, L2 Book", latency: "< 50ms", status: "active", included: false },
    ],
  },
  {
    category: "Crypto CeFi",
    feeds: [
      { name: "Binance Perps", type: "OHLCV, Funding, Liq", latency: "< 20ms", status: "active", included: true },
      { name: "Bybit Perps", type: "OHLCV, Funding", latency: "< 20ms", status: "active", included: true },
      { name: "Deribit Options", type: "IV, Greeks, Book", latency: "< 30ms", status: "active", included: true },
      { name: "OKX Spot", type: "OHLCV, Tick", latency: "< 20ms", status: "active", included: false },
    ],
  },
  {
    category: "DeFi",
    feeds: [
      { name: "Uniswap V3", type: "Swaps, Pool State", latency: "< 2 blocks", status: "active", included: true },
      { name: "Aave V3", type: "Rates, Positions", latency: "< 2 blocks", status: "active", included: true },
      { name: "Chainlink Oracles", type: "Price Feeds", latency: "< 1 block", status: "active", included: false },
    ],
  },
  {
    category: "Sports",
    feeds: [
      { name: "Betfair Exchange", type: "Odds, Volume", latency: "< 100ms", status: "active", included: true },
      { name: "Pinnacle", type: "Odds, Lines", latency: "< 200ms", status: "active", included: true },
      { name: "Multiple Books", type: "Arb Opportunities", latency: "< 500ms", status: "active", included: false },
    ],
  },
]

// Mock API keys
const mockApiKeys = [
  { id: "key_1", name: "Production", key: "odum_live_sk_abc123...", created: "2024-01-15", lastUsed: "2 min ago", calls: 847293 },
  { id: "key_2", name: "Development", key: "odum_test_sk_xyz789...", created: "2024-02-01", lastUsed: "1 hour ago", calls: 12453 },
]

// Mock usage
const mockUsage = {
  plan: "Professional",
  callsUsed: 847293,
  callsLimit: 1000000,
  dataPointsUsed: 42_500_000,
  dataPointsLimit: 50_000_000,
  renewalDate: "April 1, 2026",
  monthlyPrice: 499,
}

// Mock one-off purchases (like tardis.dev)
const mockPurchases = [
  { id: "hist_1", name: "BTC Historical 2020-2023", type: "Binance Perps", size: "12.4 GB", price: 299, status: "available" },
  { id: "hist_2", name: "ETH Options Full History", type: "Deribit", size: "8.2 GB", price: 199, status: "available" },
  { id: "hist_3", name: "Sports Odds Archive 2022", type: "Multi-book", size: "5.1 GB", price: 149, status: "purchased" },
]

export default function DataProvisionPage() {
  const [searchQuery, setSearchQuery] = React.useState("")
  const [showKey, setShowKey] = React.useState<string | null>(null)

  const usagePercent = (mockUsage.callsUsed / mockUsage.callsLimit) * 100

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex h-14 items-center gap-4 px-4 md:px-6">
          <Link href="/portal/dashboard" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="size-4" />
          </Link>
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-lg bg-sky-400/10">
              <Database className="size-4 text-sky-400" />
            </div>
            <span className="font-semibold">Data Provision</span>
          </div>
          <Badge variant="outline" className="ml-auto">
            {mockUsage.plan}
          </Badge>
        </div>
      </header>

      <main className="container px-4 py-6 md:px-6">
        {/* Usage Overview */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">API Calls</span>
                <Activity className="size-4 text-sky-400" />
              </div>
              <div className="mt-2 text-2xl font-bold">{(mockUsage.callsUsed / 1000).toFixed(0)}k</div>
              <Progress value={usagePercent} className="mt-2 h-1" />
              <div className="mt-1 text-xs text-muted-foreground">
                of {(mockUsage.callsLimit / 1000000).toFixed(0)}M limit
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Data Points</span>
                <Zap className="size-4 text-amber-400" />
              </div>
              <div className="mt-2 text-2xl font-bold">{(mockUsage.dataPointsUsed / 1000000).toFixed(1)}M</div>
              <Progress value={(mockUsage.dataPointsUsed / mockUsage.dataPointsLimit) * 100} className="mt-2 h-1" />
              <div className="mt-1 text-xs text-muted-foreground">
                of {(mockUsage.dataPointsLimit / 1000000).toFixed(0)}M limit
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Active Feeds</span>
                <Globe className="size-4 text-emerald-400" />
              </div>
              <div className="mt-2 text-2xl font-bold">18</div>
              <div className="mt-1 text-xs text-muted-foreground">
                across 4 asset classes
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Avg Latency</span>
                <Clock className="size-4 text-violet-400" />
              </div>
              <div className="mt-2 text-2xl font-bold">24ms</div>
              <div className="mt-1 text-xs text-muted-foreground">
                p99: 87ms
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="catalog" className="mt-8">
          <TabsList>
            <TabsTrigger value="catalog">Data Catalog</TabsTrigger>
            <TabsTrigger value="api-keys">API Keys</TabsTrigger>
            <TabsTrigger value="historical">Historical Data</TabsTrigger>
            <TabsTrigger value="docs">Documentation</TabsTrigger>
          </TabsList>

          {/* Data Catalog */}
          <TabsContent value="catalog" className="mt-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search feeds..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="mr-2 size-4" />
                Filter
              </Button>
            </div>

            <div className="space-y-6">
              {dataCategories.map((category) => (
                <Card key={category.category}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">{category.category}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Feed</TableHead>
                          <TableHead>Data Types</TableHead>
                          <TableHead>Latency</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="text-right">Access</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {category.feeds.map((feed) => (
                          <TableRow key={feed.name}>
                            <TableCell className="font-medium">{feed.name}</TableCell>
                            <TableCell className="text-muted-foreground">{feed.type}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="text-xs">{feed.latency}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1.5">
                                <div className="size-2 rounded-full bg-emerald-500" />
                                <span className="text-xs text-muted-foreground">Active</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              {feed.included ? (
                                <Badge variant="outline" className="text-emerald-500 border-emerald-500/30">
                                  <CheckCircle2 className="mr-1 size-3" />
                                  Included
                                </Badge>
                              ) : (
                                <Button size="sm" variant="outline">
                                  <Plus className="mr-1 size-3" />
                                  Add
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* API Keys */}
          <TabsContent value="api-keys" className="mt-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold">API Keys</h3>
                <p className="text-sm text-muted-foreground">Manage your API keys for data access</p>
              </div>
              <Button size="sm">
                <Plus className="mr-2 size-4" />
                Create Key
              </Button>
            </div>

            <Card>
              <CardContent className="pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Key</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Last Used</TableHead>
                      <TableHead>Calls</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockApiKeys.map((apiKey) => (
                      <TableRow key={apiKey.id}>
                        <TableCell className="font-medium">{apiKey.name}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <code className="text-xs bg-muted px-2 py-1 rounded">
                              {showKey === apiKey.id ? apiKey.key : "odum_****_sk_****..."}
                            </code>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-6"
                              onClick={() => setShowKey(showKey === apiKey.id ? null : apiKey.id)}
                            >
                              {showKey === apiKey.id ? <EyeOff className="size-3" /> : <Eye className="size-3" />}
                            </Button>
                            <Button variant="ghost" size="icon" className="size-6">
                              <Copy className="size-3" />
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{apiKey.created}</TableCell>
                        <TableCell className="text-muted-foreground">{apiKey.lastUsed}</TableCell>
                        <TableCell>{apiKey.calls.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" className="text-destructive">
                            Revoke
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Historical Data (like tardis.dev) */}
          <TabsContent value="historical" className="mt-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold">Historical Data</h3>
                <p className="text-sm text-muted-foreground">One-time purchases for historical datasets</p>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              {mockPurchases.map((item) => (
                <Card key={item.id} className={cn(item.status === "purchased" && "border-emerald-500/30")}>
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-base">{item.name}</CardTitle>
                      {item.status === "purchased" && (
                        <Badge variant="outline" className="text-emerald-500 border-emerald-500/30">
                          Purchased
                        </Badge>
                      )}
                    </div>
                    <CardDescription>{item.type}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Size: {item.size}</span>
                      <span className="font-semibold">${item.price}</span>
                    </div>
                    <Button
                      className="w-full mt-4"
                      variant={item.status === "purchased" ? "outline" : "default"}
                      size="sm"
                    >
                      {item.status === "purchased" ? (
                        <>
                          <Download className="mr-2 size-4" />
                          Download
                        </>
                      ) : (
                        <>
                          <ShoppingCart className="mr-2 size-4" />
                          Purchase
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="mt-6 border-dashed">
              <CardContent className="py-8 text-center">
                <Database className="mx-auto size-8 text-muted-foreground" />
                <h3 className="mt-4 font-semibold">Need Custom Historical Data?</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Contact us for custom date ranges, specific instruments, or bulk pricing.
                </p>
                <Button variant="outline" className="mt-4">
                  Request Custom Data
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documentation */}
          <TabsContent value="docs" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>API Documentation</CardTitle>
                <CardDescription>Get started with the Data Provision API</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg bg-muted p-4">
                  <div className="text-sm font-medium mb-2">Base URL</div>
                  <code className="text-xs bg-background px-2 py-1 rounded">
                    https://api.odum-research.co.uk/v1/data
                  </code>
                </div>
                <div className="rounded-lg bg-muted p-4">
                  <div className="text-sm font-medium mb-2">Example Request</div>
                  <pre className="text-xs bg-background p-3 rounded overflow-x-auto">
{`curl -X GET "https://api.odum-research.co.uk/v1/data/ohlcv" \\
  -H "Authorization: Bearer odum_live_sk_..." \\
  -d "symbol=BTC-PERP" \\
  -d "exchange=binance" \\
  -d "interval=1h" \\
  -d "limit=100"`}
                  </pre>
                </div>
                <Button variant="outline">
                  View Full Documentation
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
